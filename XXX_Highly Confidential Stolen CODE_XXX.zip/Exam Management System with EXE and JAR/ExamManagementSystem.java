/**
 * Filename: ExamManagementSystem.java
 * Authors: Anulmi Fernando, Athar Wadud Fida
 * Date: June 07, 2023
 */

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

 /**
 * The class Exam management system
 */ 
public class ExamManagementSystem {

    /**
     * Represents a JFrame.
     */
    private JFrame frame;
    
    /**
     * Flag indicating whether the admission form has been shown or not.
     * If true, the admission form has been shown; otherwise, it has not been shown.
     */
    private boolean admissionFormShown;

/** 
 *
 * A constructor class. 
 *
 */
    public ExamManagementSystem() {
        frame = new JFrame("ExamFinity");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(680, 450);
        admissionFormShown = false; 

        createInitialInterface();
    }

/** 
 *
 * Create initial interface
 *
 */
private void createInitialInterface() {
    // Loads the background image
    ImageIcon backgroundImage = new ImageIcon("ExamFinity.jpg"); 

    // Creates a JLabel with the background image icon
    JLabel backgroundLabel = new JLabel(backgroundImage);
    backgroundLabel.setBounds(0, 0, backgroundImage.getIconWidth(), backgroundImage.getIconHeight());

    // Creates a JLayeredPane to hold the components
    JLayeredPane layeredPane = new JLayeredPane();
    layeredPane.setPreferredSize(new Dimension(backgroundImage.getIconWidth(), backgroundImage.getIconHeight()));
    layeredPane.add(backgroundLabel, JLayeredPane.DEFAULT_LAYER);

    // Creates the button panel
    JPanel buttonPanel = new JPanel();
    buttonPanel.setOpaque(false); // Make the panel transparent
    buttonPanel.setBounds(0, 0, backgroundImage.getIconWidth(), 100); // Adjust the height as needed

    // Creates the buttons
    JButton studentModeButton = new JButton("Student Mode");
    JButton adminModeButton = new JButton("Admin Mode");
    JButton exitButton = new JButton("Exit");
    JButton helpButton = new JButton("Help");
    
    helpButton.addActionListener(new ActionListener(){
        @Override
        /** 
         *
         * Action performed
         *
         * @param e  the e. 
         */
        public void actionPerformed(ActionEvent e) {
            openDocumentation();
        }
    });

    
    
    Font buttonFont = new Font(studentModeButton.getFont().getName(), Font.BOLD, 18); // Adjusts the font size 
    studentModeButton.setFont(buttonFont);
    adminModeButton.setFont(buttonFont);
    helpButton.setFont(buttonFont);
    exitButton.setFont(buttonFont);
	

    // Add action listeners to the buttons
    studentModeButton.addActionListener(e -> {
        // Handle student mode button action
        showAdmissionForm();
    });

    adminModeButton.addActionListener(e -> {
        // Handle admin mode button action
        showAdminLogin();
    });

    exitButton.addActionListener(e -> {
        // Handle exit button action
        System.exit(0);
    });

    // Set the button size
    Dimension buttonSize = new Dimension(160, 50); // Adjust the width and height of the buttons
    studentModeButton.setPreferredSize(buttonSize);
    adminModeButton.setPreferredSize(buttonSize);
    helpButton.setPreferredSize(buttonSize);
    exitButton.setPreferredSize(buttonSize);
	


    // Add the buttons to the button panel
    buttonPanel.add(studentModeButton);
    buttonPanel.add(adminModeButton);
    buttonPanel.add(helpButton);
    buttonPanel.add(exitButton);
    
    // Add the button panel to the layered pane
    layeredPane.add(buttonPanel, JLayeredPane.PALETTE_LAYER);

    // Create the main panel and add the layered pane
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(layeredPane, BorderLayout.CENTER);

    // Set the main panel as the content pane of the frame
    frame.setContentPane(panel);
    frame.pack();
    frame.setVisible(true);
}

/** 
 *
 * Open the Exam Management System help documentation.
 *
 */
private void openDocumentation() {
    try {
        // Open the documentation URL in the default browser
        URI documentationUri = new URI("https://github.com/obsidzx/Help/blob/main/README.md"); 
        Desktop.getDesktop().browse(documentationUri);
    } catch (URISyntaxException | IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(frame, "Failed to open documentation.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

/** 
 *
 * Show the admission form
 *
 */
private void showAdmissionForm() {
    JPanel panel = new JPanel() {
        @Override
        /** 
         *
         * Paint component
         *
         * @param g  the g. 
         */
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Load the background image
            ImageIcon backgroundImage = new ImageIcon("ExamFinity1.jpg");
            Image img = backgroundImage.getImage();
            g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
        }
    };

    // Set the preferred size of the panel
    ImageIcon backgroundImage = new ImageIcon("ExamFinity1.jpg");
    panel.setPreferredSize(new Dimension(backgroundImage.getIconWidth(), backgroundImage.getIconHeight()));
        
        panel.setLayout(new GridLayout(6, 2));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);

        JLabel admissionNumberLabel = new JLabel("Student number:");
        JTextField admissionNumberField = new JTextField(20);

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);

        JButton saveButton = new JButton("Save and go to instructions");
        saveButton.setPreferredSize(new Dimension(150, 30));
        saveButton.addActionListener(e -> {
            // Handle save button action
            String name = nameField.getText();
            String admissionNumber = admissionNumberField.getText();
            String email = emailField.getText();

            if (isValidAdmissionForm(name, admissionNumber, email)) {
                saveStudentDetails(name, admissionNumber, email); // Save student details to file
                showExamInstructions(name, admissionNumber, email);
            } else {
                JOptionPane.showMessageDialog(frame, "Please fill in all the fields!");
            }
        });

        JButton backButton = new JButton("Back to main page");
        backButton.setPreferredSize(new Dimension(150, 30));
        backButton.addActionListener(e -> {
            // Handle back button action
            createInitialInterface();
        });

        // Set font size for labels, buttons, and text fields
        Font font = new Font("Arial", Font.BOLD, 18);
        nameLabel.setFont(font);
        admissionNumberLabel.setFont(font);
        emailLabel.setFont(font);
        saveButton.setFont(font);
        backButton.setFont(font);
        nameField.setFont(font);
        admissionNumberField.setFont(font);
        emailField.setFont(font);

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(admissionNumberLabel);
        panel.add(admissionNumberField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(saveButton);
        panel.add(backButton);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.add(panel, new GridBagConstraints());

        frame.getContentPane().removeAll();
        frame.getContentPane().add(mainPanel);
        frame.revalidate();
        frame.repaint();

        admissionFormShown = true; 
    }

    /** 
     *
     * Checking whether if it's a valid admission form or not.
     *
     * @param name  the name. 
     * @param admissionNumber  the admission number. 
     * @param email  the email. 
     * @return boolean
     */
    private boolean isValidAdmissionForm(String name, String admissionNumber, String email) {
        return !name.isEmpty() && !admissionNumber.isEmpty() && !email.isEmpty();
    }

    /** 
     *
     * Save student details in a text file.
     *
     * @param name  the name. 
     * @param admissionNumber  the student number. 
     * @param email  the email. 
     */
    private void saveStudentDetails(String name, String admissionNumber, String email) {
        try (FileWriter writer = new FileWriter("Studentdetails.txt", true)) { // Append to the file
            writer.write("Name: " + name + "\n");
            writer.write("Student number: " + admissionNumber + "\n");
            writer.write("Email: " + email + "\n");
            writer.write("-----------------------------------------------------\n"); // Add a separator between student entries

            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

/** 
 *
 * Show exam instructions.
 *
 * @param name  the name. 
 * @param admissionNumber  the student number. 
 * @param email  the email. 
 */
private void showExamInstructions(String name, String admissionNumber, String email) {
        JPanel panel = new JPanel(new BorderLayout()) {
        @Override
        /** 
         *
         * Paint component
         *
         * @param g  the g. 
         */
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Load the background image
            ImageIcon backgroundImage = new ImageIcon("ExamFinity2.jpg"); 
            g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
        }
    };

    // Set the preferred size of the panel
    ImageIcon backgroundImage = new ImageIcon("ExamFinity2.jpg");
    panel.setPreferredSize(new Dimension(backgroundImage.getIconWidth(), backgroundImage.getIconHeight()));
    
    panel.setLayout(new BorderLayout());
    
        JTextArea instructionsArea = new JTextArea();
        instructionsArea.setEditable(false);
        instructionsArea.setFont(new Font("Arial", Font.PLAIN, 27)); 
        instructionsArea.setText("\n\n                                 Exam Instructions\n\n1. Read the questions carefully.\n2. Once you submitted a question you can not go back.\n3. To skip a question click 'Skip' \n    To submit an answer click 'Submit', \n4. Student must not use their textbooks or any other \n    books during the quiz period\n5. Good luck!"); // Instructions

        panel.add(new JScrollPane(instructionsArea), BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            // Handle back button action
            showAdmissionForm();
        });

        JButton startExamButton = new JButton("Start the exam");
        startExamButton.addActionListener(e -> {
            // Handle start exam button action
            //startExam(name, studentNumber, email);
            Exam exam=new Exam();
            frame.dispose();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(backButton);
        buttonPanel.add(startExamButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();
    }

/** 
 *
 * Show admin login screen.
 *
 */
private void showAdminLogin() {
    JPanel panel = new JPanel() {
        @Override
        /** 
         *
         * Paint component
         *
         * @param g  the g. 
         */
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Load the background image
            ImageIcon backgroundImage = new ImageIcon("passwordbg.png");  
            g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    // Set the layout to null to position components manually
    panel.setLayout(null);
    
    JLabel usernameLabel = new JLabel("Username:");
    JTextField usernameField = new JTextField(10);
    
    JLabel passwordLabel = new JLabel("Password:");
    JPasswordField passwordField = new JPasswordField(10);
    
    Font labelFont = new Font(usernameLabel.getFont().getName(), Font.BOLD, 18); 
    Font fieldFont = new Font(usernameField.getFont().getName(), Font.BOLD, 18); 
    usernameLabel.setFont(labelFont);
    passwordLabel.setFont(labelFont);
    usernameField.setFont(fieldFont);
    passwordField.setFont(fieldFont);
    
    JButton loginButton = new JButton("Login");
    loginButton.addActionListener(e -> {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        if (isValidAdminCredentials(username, password)) {
            showAdminNavigationBar();
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid username or password!");
        }
    });
    
    JButton clearButton = new JButton("Clear");
    clearButton.addActionListener(e -> {
        usernameField.setText("");
        passwordField.setText("");
    });
    
    // Set the bounds of the components
    usernameLabel.setBounds(50, 100, 100, 30);
    usernameField.setBounds(160, 100, 200, 30);
    passwordLabel.setBounds(50, 150, 100, 30);
    passwordField.setBounds(160, 150, 200, 30);
    loginButton.setBounds(160, 200, 100, 30);
    clearButton.setBounds(260, 200, 100, 30);
    
    // Add the components to the panel
    panel.add(usernameLabel);
    panel.add(usernameField);
    panel.add(passwordLabel);
    panel.add(passwordField);
    panel.add(loginButton);
    panel.add(clearButton);
    
    frame.getContentPane().removeAll();
    frame.getContentPane().add(panel);
    frame.revalidate();
    frame.repaint();
}

    /** 
     *
     * Checking whether the username and password correct. 
     *
     * @param username  the username. 
     * @param password  the password. 
     * @return boolean
     */
    private boolean isValidAdminCredentials(String username, String password) {
    
        return username.equals("admin") && password.equals("password"); // Set the username and the password.
    }
    
    /** 
     *
     * Show admin navigation bar.
     *
     */
    public void showAdminNavigationBar() {
        JPanel panel = new JPanel(new BorderLayout()) {
        @Override
        /** 
         *
         * Paint component
         *
         * @param g  the g. 
         */
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Load the background image for navigation bar
            ImageIcon backgroundImage = new ImageIcon("Questionbg4.jpg");  
            g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), 175, this);
        }
    };
        
        JButton addQuestionButton = new JButton("Add New Question");
        addQuestionButton.addActionListener(e -> {
            // Handle add question button action
            AddNewQuestion addnewquestion= new AddNewQuestion();
            frame.dispose();
            
        });
        
        JButton updateQuestionButton = new JButton("Update and Delete Question");
        
        updateQuestionButton.addActionListener(e -> {
            // Handle update and delete question button action
            UpdateAndDeleteQuestion updatequestion= new UpdateAndDeleteQuestion();
            frame.dispose();
        });
        
        JButton allQuestionsButton = new JButton("All Questions");
        allQuestionsButton.addActionListener(e -> {
            // Handle all questions button action
            AllQuestions allquestion= new AllQuestions();
            frame.dispose();
        });
        
        
        JButton allStudentResultsButton = new JButton("All Student Details");
        allStudentResultsButton.addActionListener(e -> {
            // Handle all student results button actionstudent results");
            displayStudentResults();
        });
        
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> {
            // Handle logout button action
            createInitialInterface();
        });
        
        JButton exitButton = new JButton("Exit");
        
        exitButton.addActionListener(e -> {
            // Handle exit button action
            System.exit(0);
        });
        //AllQuestions
        

    
        JPanel buttonPanel = new JPanel();
    
        JTextArea questionsArea = new JTextArea();
        questionsArea.setEditable(false);
        try {
            BufferedReader reader = new BufferedReader(new FileReader("questions.txt"));
            String question;
            while ((question = reader.readLine()) != null) {
                questionsArea.append(question + "\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        JScrollPane scrollPane = new JScrollPane(questionsArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
    
        
        panel.add(scrollPane, BorderLayout.SOUTH);
    
        
        buttonPanel.add(addQuestionButton);
        buttonPanel.add(updateQuestionButton);
        buttonPanel.add(allStudentResultsButton);
        buttonPanel.add(logoutButton);
        buttonPanel.add(exitButton);
        
        panel.add(buttonPanel, BorderLayout.NORTH);
        
        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();
    }

/** 
 *
 * Display student results.
 *
 */
 private void displayStudentResults() {
    try {
        // Read the contents of the "Studentdetails.txt" file
        File file = new File("Studentdetails.txt");
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        StringBuilder content = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            content.append(line).append("\n");
        }

        bufferedReader.close();

        // Display the student results
        JTextArea resultsArea = new JTextArea();
        resultsArea.setEditable(false);
        resultsArea.setText(content.toString());

        JScrollPane scrollPane = new JScrollPane(resultsArea);
        scrollPane.setPreferredSize(new Dimension(500, 300)); // Adjust the preferred size as needed

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Create the sorting menu
        JMenuBar menuBar = new JMenuBar();
        JMenu sortMenu = new JMenu("Sort");
        JMenuItem sortByNameItem = new JMenuItem("Sort by Name");
        JMenuItem sortByAdmissionNumberItem = new JMenuItem("Sort by Student Number");

        sortByNameItem.addActionListener(e -> {
            sortStudentDetailsByName(resultsArea);
        });

        sortByAdmissionNumberItem.addActionListener(e -> {
            sortStudentDetailsByAdmissionNumber(resultsArea);
        });

        sortMenu.add(sortByNameItem);
        sortMenu.add(sortByAdmissionNumberItem);
        menuBar.add(sortMenu);

        panel.add(menuBar, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        JFrame resultsFrame = new JFrame("All Student Details");
        resultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resultsFrame.setSize(600, 400); // Adjust the size as needed
        resultsFrame.setContentPane(panel);
        resultsFrame.setVisible(true);

    } catch (IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(frame, "Failed to read the file.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

/** 
 *
 * Sort student details by name.
 *
 * @param resultsArea  the results area. 
 */
private void sortStudentDetailsByName(JTextArea resultsArea) {
    String[] studentBlocks = resultsArea.getText().split("--------------------------------\n");
    
    Arrays.sort(studentBlocks, (block1, block2) -> {
        String name1 = getNameValue(block1);
        String name2 = getNameValue(block2);
        return name1.compareToIgnoreCase(name2);
    });

    resultsArea.setText(String.join("--------------------------------\n", studentBlocks));
}


/** 
 *
 * Sort student details by admission number
 *
 * @param resultsArea  the results area. 
 */
private void sortStudentDetailsByAdmissionNumber(JTextArea resultsArea) {
    String[] studentBlocks = resultsArea.getText().split("--------------------------------\n");
    
    Arrays.sort(studentBlocks, (block1, block2) -> {
        long admissionNumber1 = getAdmissionNumberValue(block1);
        long admissionNumber2 = getAdmissionNumberValue(block2);
        return Long.compare(admissionNumber1, admissionNumber2);
    });

    resultsArea.setText(String.join("--------------------------------\n", studentBlocks));
}

/** 
 *
 * Gets the name value
 *
 * @param block  the block. 
 * @return the name value
 */
private String getNameValue(String block) {
    String[] lines = block.split("\n");
    for (String line : lines) {
        String[] parts = line.split(": ");
        if (parts.length >= 2 && parts[0].equals("Name")) {
            return parts[1];
        }
    }
    return "";
}

/** 
 *
 * Gets the admission number value
 *
 * @param block  the block. 
 * @return the admission number value
 */
private long getAdmissionNumberValue(String block) {
    String[] lines = block.split("\n");
    for (String line : lines) {
        String[] parts = line.split(": ");
        if (parts.length >= 2 && parts[0].equals("Student number")) {
            String admissionNumberStr = parts[1].replaceAll("[^\\d]", "");
            try {
                return Long.parseLong(admissionNumberStr);
            } catch (NumberFormatException e) {
                return 0L;
            }
        }
    }
    return 0L;
}



        /** 
         *
         * Show initial interface
         *
         */
        private void showInitialInterface() {
        JPanel panel = new JPanel();
        // Check if admission form was previously shown
        if (!admissionFormShown) {
            JButton backButton = new JButton("Back to main page");
            backButton.addActionListener(e -> {
                // Handle back button action
                showInitialInterface();
            });
            panel.add(backButton);
        }

        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();

        admissionFormShown = false; 
    }
    
    /** 
     *
     * Main method to start the application.
     *
     * @param args  the args. 
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExamManagementSystem());
    }
} 