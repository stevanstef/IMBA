/**
 * Filename: UpdateAndDeleteQuestion.java
 * Authors: Anulmi Fernando, Athar Wadud Fida
 * Date: June 07, 2023
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * A class representing the Update and Delete Question window of the Exam Management System.
 * Allows the user to search, update, and delete a specific question.
 */
public class UpdateAndDeleteQuestion extends JFrame {

    /**
     * The text field for searching a question.
     */
    private JTextField searchTextField;

    /**
     * The text area for entering the question.
     */
    private JTextArea questionTextArea;

    /**
     * The text field for entering option 1.
     */
    private JTextField option1TextField;

    /**
     * The text field for entering option 2.
     */
    private JTextField option2TextField;

    /**
     * The text field for entering option 3.
     */
    private JTextField option3TextField;

    /**
     * The text field for entering option 4.
     */
    private JTextField option4TextField;

    /**
     * The text field for entering the answer.
     */
    private JTextField answerTextField;

    /**
     * Constructs an UpdateAndDeleteQuestion object and initializes the UI components.
     */
    public UpdateAndDeleteQuestion() {
        setTitle("Update and Delete Question");
        setSize(520, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        JLabel backgroundLabel = new JLabel(new ImageIcon("Questionbg2.jpg"));
        backgroundLabel.setLayout(null);
        add(backgroundLabel);

        JPanel mainPanel = new JPanel();
        mainPanel.setBounds(50, 50, 400, 450);
        mainPanel.setLayout(null);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        // Admin Navigation Bar menu item
        JMenuItem adminNavigationBarMenuItem = new JMenuItem("Admin Navigation Bar");
        adminNavigationBarMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ExamManagementSystem ems = new ExamManagementSystem();
                ems.showAdminNavigationBar();
                dispose();
            }
        });
        fileMenu.add(adminNavigationBarMenuItem);

        // All Questions menu item
        JMenuItem allQuestionsMenuItem = new JMenuItem("All Questions");
        allQuestionsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllQuestions();
                dispose();
            }
        });
        fileMenu.add(allQuestionsMenuItem);

        // Add New Question menu item
        JMenuItem addNewQuestionMenuItem = new JMenuItem("Add New Question");
        addNewQuestionMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddNewQuestion();
                dispose();
            }
        });
        fileMenu.add(addNewQuestionMenuItem);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        JLabel searchLabel = new JLabel("Question Number:");
        searchLabel.setBounds(20, 20, 120, 25);
        searchTextField = new JTextField();
        searchTextField.setBounds(155, 20, 40, 25);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(250, 20, 80, 25);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchQuestion();
            }
        });

        JLabel questionLabel = new JLabel("Question:");
        questionLabel.setBounds(20, 60, 100, 25);
        questionTextArea = new JTextArea();
        JScrollPane questionScrollPane = new JScrollPane(questionTextArea);
        questionScrollPane.setBounds(125, 60, 250, 100);

        JLabel option1Label = new JLabel("Option 1:");
        option1Label.setBounds(20, 180, 100, 25);
        option1TextField = new JTextField();
        option1TextField.setBounds(125, 180, 250, 25);

        JLabel option2Label = new JLabel("Option 2:");
        option2Label.setBounds(20, 220, 100, 25);
        option2TextField = new JTextField();
        option2TextField.setBounds(125, 220, 250, 25);

        JLabel option3Label = new JLabel("Option 3:");
        option3Label.setBounds(20, 260, 100, 25);
        option3TextField = new JTextField();
        option3TextField.setBounds(125, 260, 250, 25);

        JLabel option4Label = new JLabel("Option 4:");
        option4Label.setBounds(20, 300, 100, 25);
        option4TextField = new JTextField();
        option4TextField.setBounds(125, 300, 250, 25);

        JLabel answerLabel = new JLabel("Answer:");
        answerLabel.setBounds(20, 340, 100, 25);
        answerTextField = new JTextField();
        answerTextField.setBounds(125, 340, 250, 25);

        JButton saveButton = new JButton("Save");
        saveButton.setBounds(20, 390, 80, 25);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveQuestion();
            }
        });

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(293, 390, 80, 25);
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(147, 390, 100, 25);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteQuestion();
            }
        });

        mainPanel.add(searchLabel);
        mainPanel.add(searchTextField);
        mainPanel.add(searchButton);
        mainPanel.add(questionLabel);
        mainPanel.add(questionScrollPane);
        mainPanel.add(option1Label);
        mainPanel.add(option1TextField);
        mainPanel.add(option2Label);
        mainPanel.add(option2TextField);
        mainPanel.add(option3Label);
        mainPanel.add(option3TextField);
        mainPanel.add(option4Label);
        mainPanel.add(option4TextField);
        mainPanel.add(answerLabel);
        mainPanel.add(answerTextField);
        mainPanel.add(saveButton);
        mainPanel.add(clearButton);
        mainPanel.add(deleteButton);

        backgroundLabel.add(mainPanel);

        setVisible(true);
    }

    /**
     * Searches for a question based on the provided question number.
     * If found, populates the UI fields with the question details.
     */
    private void searchQuestion() {
        String searchNumber = searchTextField.getText();

        try {
            BufferedReader reader = new BufferedReader(new FileReader("questions.txt"));
            String line;
            boolean questionFound = false;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Question " + searchNumber)) {
                    questionFound = true;
                    String question = line.substring(line.indexOf(":") + 1).trim();
                    String optionsAndAnswer = reader.readLine();

                    String[] optionsAndAnswerParts = optionsAndAnswer.split(",");

                    questionTextArea.setText(question);
                    option1TextField.setText(optionsAndAnswerParts[0].trim());
                    option2TextField.setText(optionsAndAnswerParts[1].trim());
                    option3TextField.setText(optionsAndAnswerParts[2].trim());
                    option4TextField.setText(optionsAndAnswerParts[3].trim());
                    answerTextField.setText(optionsAndAnswerParts[4].trim());

                    break;
                }
            }
            reader.close();

            if (!questionFound) {
                JOptionPane.showMessageDialog(this, "Question not found.", "Error", JOptionPane.ERROR_MESSAGE);
                clearFields();
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to search for the question.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Saves the updated question details to the questions.txt file.
     */
    private void saveQuestion() {
        String searchNumber = searchTextField.getText();
        String updatedQuestion = questionTextArea.getText();
        String updatedOptions = option1TextField.getText().trim() + ", " +
                option2TextField.getText().trim() + ", " +
                option3TextField.getText().trim() + ", " +
                option4TextField.getText().trim();
        String updatedAnswer = answerTextField.getText().trim();

        // Create a temporary file
        File tempFile = new File("temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader("questions.txt"));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            boolean questionFound = false;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Question " + searchNumber)) {
                    questionFound = true;
                    writer.write("Question " + searchNumber + ": " + updatedQuestion);
                    writer.newLine();
                    writer.write(updatedOptions + ", " + updatedAnswer);
                    writer.newLine();
                    reader.readLine(); // Skip the old options and answer
                } else {
                    writer.write(line);
                    writer.newLine();
                }
            }

            if (!questionFound) {
                JOptionPane.showMessageDialog(this, "Question not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Close the readers and writers
            reader.close();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to save the updated question.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        File inputFile = new File("questions.txt");
        // Delete the original file
        if (!inputFile.delete()) {
            JOptionPane.showMessageDialog(this, "Failed to delete previous question.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Rename the temporary file to the original file
        if (!tempFile.renameTo(inputFile)) {
            JOptionPane.showMessageDialog(this, "Failed to save the updated question.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        clearFields();

        JOptionPane.showMessageDialog(this, "Question updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Deletes the question from the questions.txt file.
     */
    private void deleteQuestion() {
    String searchNumber = searchTextField.getText();

    // Create a temporary file
    File tempFile = new File("temp.txt");

    try (BufferedReader reader = new BufferedReader(new FileReader("questions.txt"));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String line;
        String previousLine = null;
        boolean questionFound = false;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("Question " + searchNumber)) {
                questionFound = true;
                // Skip the question, options, and answer
                reader.readLine();
                reader.readLine();
                
            } else {
                if (previousLine != null) {
                    writer.write(previousLine);
                    writer.newLine();
                }
                previousLine = line;
            }
        }

        if (!questionFound) {
            JOptionPane.showMessageDialog(this, "Question not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (previousLine != null) {
            writer.write(previousLine);
        }

    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to delete the question.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    File inputFile = new File("questions.txt");
    // Delete the original file
    if (!inputFile.delete()) {
        JOptionPane.showMessageDialog(this, "Failed to delete previous question.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Rename the temporary file to the original file
    if (!tempFile.renameTo(inputFile)) {
        JOptionPane.showMessageDialog(this, "Failed to delete the question.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    clearFields();

    JOptionPane.showMessageDialog(this, "Question deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
}



    /**
     * Clears all the fields in the UI.
     */
    private void clearFields() {
        searchTextField.setText("");
        questionTextArea.setText("");
        option1TextField.setText("");
        option2TextField.setText("");
        option3TextField.setText("");
        option4TextField.setText("");
        answerTextField.setText("");
    }

    /**
     * The entry point of the program.
     *
     * @param args the command-line arguments passed to the program
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new UpdateAndDeleteQuestion();
            }
        });
    }
}
