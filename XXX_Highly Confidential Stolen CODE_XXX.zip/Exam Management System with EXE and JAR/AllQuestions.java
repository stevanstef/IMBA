/**
 * Filename: AllQuestions.java
 * Authors: Anulmi Fernando, Athar Wadud Fida
 * Date: June 07, 2023
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Represents a JFrame that displays all the questions.
 */
public class AllQuestions extends JFrame {

    /**
     * Represents a JTextArea used to display questions.
     */
    private JTextArea questionTextArea;

    /**
     * Constructs an instance of the AllQuestions class.
     * Sets up the JFrame with question display area and menu bar.
     */
    public AllQuestions() {
        setTitle("All Questions");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(680, 450));
        setLocationRelativeTo(null);

        questionTextArea = new JTextArea();
        questionTextArea.setEditable(false);
        questionTextArea.setFont(new Font("Arial", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(questionTextArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        add(scrollPane);

        // Load questions and display them
        loadQuestions();

        pack();
        setVisible(true);

        // Create and set up the menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        // Admin Navigation Bar menu item
        JMenuItem adminNavigationBarItem = new JMenuItem("Admin Navigation Bar");
        adminNavigationBarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ExamManagementSystem ems = new ExamManagementSystem();
                ems.showAdminNavigationBar();
                dispose();
            }
        });
        fileMenu.add(adminNavigationBarItem);

        // Update and Delete Question menu item
        JMenuItem updateQuestionItem = new JMenuItem("Update and Delete Question");
        updateQuestionItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdateAndDeleteQuestion();
                dispose();
            }
        });
        fileMenu.add(updateQuestionItem);

        // Add New Question menu item
        JMenuItem addNewQuestionItem = new JMenuItem("Add New Question");
        addNewQuestionItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddNewQuestion();
                dispose();
            }
        });
        fileMenu.add(addNewQuestionItem);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    /**
     * Loads the questions from a file and displays them in the questionTextArea.
     */
    private void loadQuestions() {
        try (BufferedReader reader = new BufferedReader(new FileReader("questions.txt"))) {
            String line;
            StringBuilder questions = new StringBuilder();

            // Read each line from the file and append it to the questions StringBuilder
            while ((line = reader.readLine()) != null) {
                questions.append(line).append("\n");
            }

            // Set the text of the questionTextArea to display the loaded questions
            questionTextArea.setText(questions.toString());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load questions.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * The entry point of the application.
     * Creates an instance of AllQuestions and runs it on the Event Dispatch Thread.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(AllQuestions::new);
    }
}
