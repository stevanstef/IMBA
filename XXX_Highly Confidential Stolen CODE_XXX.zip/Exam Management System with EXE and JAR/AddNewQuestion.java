/**
 * Filename: AddNewQuestion.java
 * Authors: Anulmi Fernando, Athar Wadud Fida
 * Date: June 07, 2023
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * A JFrame for adding new questions.
 */
public class AddNewQuestion extends JFrame {

    /**
     * Text field for question number.
     */
    private JTextField questionNoTextField;

    /**
     * Text field for question.
     */
    private JTextField questionTextField;

    /**
     * Text field for option 1.
     */
    private JTextField option1TextField;

    /**
     * Text field for option 2.
     */
    private JTextField option2TextField;

    /**
     * Text field for option 3.
     */
    private JTextField option3TextField;

    /**
     * Text field for option 4.
     */
    private JTextField option4TextField;

    /**
     * Text field for answer.
     */
    private JTextField answerTextField;

    /**
     * Constructs an instance of AddNewQuestion JFrame.
     */
    public AddNewQuestion() {
        // Set JFrame properties
        setTitle("Add Question");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(600, 320));
        setLocationRelativeTo(null);

        // Create a layered pane to hold the components and background image
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(500, 420));

        // Load and set the background image
        ImageIcon backgroundImage = new ImageIcon("Questionbg.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, backgroundImage.getIconWidth(), backgroundImage.getIconHeight());
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        // Create and set up the menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        // Admin Navigation Bar menu item
        JMenuItem adminNavigationBarItem = new JMenuItem("Admin Navigation Bar");
        adminNavigationBarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ExamManagementSystem ems = new ExamManagementSystem();
                ems.showAdminNavigationBar();
                dispose();
            }
        });
        fileMenu.add(adminNavigationBarItem);

        // All Questions menu item
        JMenuItem allQuestionsItem = new JMenuItem("All Questions");
        allQuestionsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AllQuestions();
                dispose();
            }
        });
        fileMenu.add(allQuestionsItem);

        // Update and Delete Question menu item
        JMenuItem updateQuestionItem = new JMenuItem("Update and Delete Question");
        updateQuestionItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdateAndDeleteQuestion();
                dispose();
            }
        });
        fileMenu.add(updateQuestionItem);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // Create and position the components
        int componentWidth = 400;
        int componentHeight = 25;
        int componentX = 50;
        int componentY = 20;
        int componentSpacing = 30;

        // Question No label and text field
        JLabel questionNoLabel = new JLabel("Question No:");
        questionNoLabel.setBounds(componentX, componentY, 100, componentHeight);
        questionNoLabel.setForeground(Color.WHITE);
        layeredPane.add(questionNoLabel, Integer.valueOf(1));

        questionNoTextField = new JTextField();
        questionNoTextField.setBounds(componentX + 100, componentY, 35, componentHeight);
        layeredPane.add(questionNoTextField, Integer.valueOf(1));

        // Question label and text field
        JLabel questionLabel = new JLabel("Question:");
        questionLabel.setBounds(componentX, componentY + componentSpacing, 100, componentHeight);
        questionLabel.setForeground(Color.WHITE);
        layeredPane.add(questionLabel, Integer.valueOf(1));

        questionTextField = new JTextField();
        questionTextField.setBounds(componentX + 100, componentY + componentSpacing, componentWidth, componentHeight);
        layeredPane.add(questionTextField, Integer.valueOf(1));

        // Option 1 label and text field
        JLabel option1Label = new JLabel("Option 1:");
        option1Label.setBounds(componentX, componentY + 2 * componentSpacing, 100, componentHeight);
        option1Label.setForeground(Color.WHITE);
        layeredPane.add(option1Label, Integer.valueOf(1));

        option1TextField = new JTextField();
        option1TextField.setBounds(componentX + 100, componentY + 2 * componentSpacing, componentWidth, componentHeight);
        layeredPane.add(option1TextField, Integer.valueOf(1));

        // Option 2 label and text field
        JLabel option2Label = new JLabel("Option 2:");
        option2Label.setBounds(componentX, componentY + 3 * componentSpacing, 100, componentHeight);
        option2Label.setForeground(Color.WHITE);
        layeredPane.add(option2Label, Integer.valueOf(1));

        option2TextField = new JTextField();
        option2TextField.setBounds(componentX + 100, componentY + 3 * componentSpacing, componentWidth, componentHeight);
        layeredPane.add(option2TextField, Integer.valueOf(1));

        // Option 3 label and text field
        JLabel option3Label = new JLabel("Option 3:");
        option3Label.setBounds(componentX, componentY + 4 * componentSpacing, 100, componentHeight);
        option3Label.setForeground(Color.WHITE);
        layeredPane.add(option3Label, Integer.valueOf(1));

        option3TextField = new JTextField();
        option3TextField.setBounds(componentX + 100, componentY + 4 * componentSpacing, componentWidth, componentHeight);
        layeredPane.add(option3TextField, Integer.valueOf(1));

        // Option 4 label and text field
        JLabel option4Label = new JLabel("Option 4:");
        option4Label.setBounds(componentX, componentY + 5 * componentSpacing, 100, componentHeight);
        option4Label.setForeground(Color.WHITE);
        layeredPane.add(option4Label, Integer.valueOf(1));

        option4TextField = new JTextField();
        option4TextField.setBounds(componentX + 100, componentY + 5 * componentSpacing, componentWidth, componentHeight);
        layeredPane.add(option4TextField, Integer.valueOf(1));

        // Answer label and text field
        JLabel answerLabel = new JLabel("Answer:");
        answerLabel.setBounds(componentX, componentY + 6 * componentSpacing, 100, componentHeight);
        answerLabel.setForeground(Color.WHITE);
        layeredPane.add(answerLabel, Integer.valueOf(1));

        answerTextField = new JTextField();
        answerTextField.setBounds(componentX + 100, componentY + 6 * componentSpacing, componentWidth, componentHeight);
        layeredPane.add(answerTextField, Integer.valueOf(1));

        // Save button
        JButton saveButton = new JButton("Save");
        saveButton.setBounds(componentX + 170, componentY + 7 * componentSpacing, 80, componentHeight);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveQuestion();
            }
        });
        layeredPane.add(saveButton, Integer.valueOf(1));

        // Clear button
        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(componentX + 260, componentY + 7 * componentSpacing, 80, componentHeight);
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
        layeredPane.add(clearButton, Integer.valueOf(1));

        // Set the layered pane as the content pane of the frame
        setContentPane(layeredPane);

        pack();
        setVisible(true);
    }

    /**
     * Saves the question entered by the user to a file.
     */
    private void saveQuestion() {
        // Get the input values
        String questionNo = questionNoTextField.getText();
        String question = questionTextField.getText();
        String option1 = option1TextField.getText();
        String option2 = option2TextField.getText();
        String option3 = option3TextField.getText();
        String option4 = option4TextField.getText();
        String answer = answerTextField.getText();

        // Create the question data string
        String questionData = "Question " + questionNo + ": " + question + "\n"
                + "A. " + option1 + ", B. " + option2 + ", C. " + option3 + ", D. " + option4 + ", Answer. " + answer;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("questions.txt", true))) {
            // Write the question data to the file
            
            writer.write("\n");
            writer.write(questionData);
            writer.write("\n");
            writer.close();

            // Show success message and clear fields
            JOptionPane.showMessageDialog(this, "Question saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        } catch (IOException e) {
            e.printStackTrace();
            // Show error message if failed to save question
            JOptionPane.showMessageDialog(this, "Failed to save question.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Clears all the input fields.
     */
    private void clearFields() {
        questionNoTextField.setText("");
        questionTextField.setText("");
        option1TextField.setText("");
        option2TextField.setText("");
        option3TextField.setText("");
        option4TextField.setText("");
        answerTextField.setText("");
    }

    /**
     * Main method to start the application.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddNewQuestion::new);
    }
}
