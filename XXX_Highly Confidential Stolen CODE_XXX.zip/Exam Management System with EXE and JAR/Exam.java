/**
 * Filename: Exam.java
 * Authors: Anulmi Fernando, Athar Wadud Fida
 * Date: June 07, 2023
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

/**
 * Represents a JFrame for conducting an exam.
 */
public class Exam extends JFrame {
    /**
     * Label to display the total number of questions in the exam
     */
    private JLabel totalQuestionsLabel;
    
    /**
     * Label to display the current question
     */
    private JLabel questionLabel;
    
    /**
     * List to store all the questions
     */
    private List<String> questions;
    
    /**
     * List to store the options and answers for all the questions
     */
    private List<String> optionsAndAnswers;

    /**
     * Set to keep track of the questions that have been submitted
     */
    private Set<Integer> submittedQuestions;

    /**
     * Button group to ensure only one option can be selected at a time
     */
    private ButtonGroup optionGroup;

    /**
     * Array of radio buttons representing the options for the current question
     */
    private JRadioButton[] optionButtons;

    /**
     * Index of the current question being displayed
     */
    private int currentQuestion = 0;

    /**
     * Score of the user based on correct answers
     */
    private int score = 0;

    /**
     * Constructs an instance of the Exam JFrame.
     */
    public Exam() {
        setLayout(new BorderLayout());
        setTitle("Exam");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 140);
        setLocationRelativeTo(null);
        totalQuestionsLabel = new JLabel();

        questionLabel = new JLabel();
        JButton backButton = new JButton("Back");
        JButton nextButton = new JButton("Skip");
        JButton submitButton = new JButton("Submit");

        JPanel optionsPanel = new JPanel();
        optionGroup = new ButtonGroup();
        optionButtons = new JRadioButton[4];

        for(int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(backButton);
        buttonPanel.add(nextButton);
        buttonPanel.add(submitButton);

        JPanel infoPanel = new JPanel(new FlowLayout());
        infoPanel.add(totalQuestionsLabel);

        add(infoPanel, BorderLayout.NORTH);
        add(questionLabel, BorderLayout.WEST);
        add(optionsPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        questions = new ArrayList<>();
        optionsAndAnswers = new ArrayList<>();
        submittedQuestions = new HashSet<>();

        try {
            File file = new File("questions.txt");
            Scanner scanner = new Scanner(file);

            // Read questions and options from file
            while (scanner.hasNextLine()) {
                questions.add(scanner.nextLine());
                optionsAndAnswers.add(scanner.nextLine());
                if (scanner.hasNextLine()) {
                    scanner.nextLine();  // read and ignore the empty line
                }
            }
            totalQuestionsLabel.setText("Total questions: " + questions.size());
            loadQuestionAndOptions();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Move to the previous unanswered question
                int previousQuestion = currentQuestion;
                while (previousQuestion > 0) {
                    previousQuestion--;
                    if (!submittedQuestions.contains(previousQuestion)) {
                        currentQuestion = previousQuestion;
                        loadQuestionAndOptions();
                        break;
                    }
                }
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Move to the next unanswered question
                int nextQuestion = currentQuestion;
                while (nextQuestion < questions.size() - 1) {
                    nextQuestion++;
                    if (!submittedQuestions.contains(nextQuestion)) {
                        currentQuestion = nextQuestion;
                        loadQuestionAndOptions();
                        break;
                    }
                }
            }
        });

         submitButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 // Check if the selected option is correct and update the score
                 String correctAnswer = optionsAndAnswers.get(currentQuestion).split(", Answer. ")[1];
         
                 for (JRadioButton button : optionButtons) {
                     if (button.isSelected() && button.getText().equalsIgnoreCase(correctAnswer)) {
                         JOptionPane.showMessageDialog(null, "Correct!");
                         score++;
                         break;
                     }
                 }
         
                 submittedQuestions.add(currentQuestion);
         
                 // Move to the next unanswered question or show the final score
                 if (submittedQuestions.size() < questions.size()) {
                     int nextQuestion = currentQuestion;
                     while (nextQuestion < questions.size() - 1) {
                         nextQuestion++;
                         if (!submittedQuestions.contains(nextQuestion)) {
                             currentQuestion = nextQuestion;
                             loadQuestionAndOptions();
                             break;
                         }
                     }
                 } else {
                     showScore();
                     System.exit(0);
                 }
             }
         });


        setVisible(true);
    }

    /**
     * Loads the current question and its options into the UI.
     */
    private void loadQuestionAndOptions() {
        questionLabel.setText(questions.get(currentQuestion));
        String[] options = optionsAndAnswers.get(currentQuestion).split(", Answer. ")[0].split(", ");
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(options[i].split("\\. ")[1]);
        }
        optionGroup.clearSelection();
    }

    /**
     * Displays the final score to the user.
     */
    private void showScore() {
        JOptionPane.showMessageDialog(null, "Exam Finished!\nYour Score: " + score + "/" + questions.size());
    }

    /**
     * Main method to start the application.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Exam();
            }
        });
    }

}


